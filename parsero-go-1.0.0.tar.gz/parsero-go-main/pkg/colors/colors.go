package colors

const (
    OKGREEN = "\033[92m"
    FAIL    = "\033[91m"
    ENDC    = "\033[0m"
    YELLOW  = "\033[33m"
)
